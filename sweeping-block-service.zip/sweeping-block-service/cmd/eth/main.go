package main

import (
	"context"
	"fmt"
	"golang.org/x/time/rate"
	"gopkg.in/yaml.v3"
	"log"
	"math/big"
	"os"
	"strings"
	"sync"
	"time"

	"github.com/ethereum/go-ethereum/core/types"
	"github.com/ethereum/go-ethereum/ethclient"
	"gorm.io/driver/mysql"
	"gorm.io/gorm"
)

var Configs Config

// Config represents the configuration structure
type Config struct {
	Database   DatabaseConfig `yaml:"databaseConfig"`
	StartBlock int64          `yaml:"startBlock"`
}

// DatabaseConfig holds the database connection details
type DatabaseConfig struct {
	Host     string `yaml:"host"`
	Port     int    `yaml:"port"`
	Username string `yaml:"username"`
	Password string `yaml:"password"` // second
	Dbname   string `yaml:"dbname"`   // second
}

// Transaction represents a blockchain transaction
type Transaction struct {
	From        string `gorm:"primaryKey"`
	To          string
	TxHash      string
	BlockNumber uint64
	Amount      string
}

// InitConfigDev 初始化yaml config
func initConfigDev() error {

	file, err := os.ReadFile("C:\\Users\\Administrator\\GolandProjects\\sweeping-block-service\\config\\config.yaml")
	if err != nil {
		log.Println("read config-dev.yaml fail", err)
		return err
	}

	err = yaml.Unmarshal(file, &Configs)
	if err != nil {
		log.Println("yaml unmarshal fail")
		return err
	}
	return nil
}

func main() {
	// 加载配置
	if err := initConfigDev(); err != nil {
		log.Fatalf("Error unmarshalling config: %v", err)
	}

	// MySQL 数据库连接信息
	dsn := fmt.Sprintf("%s:%s@tcp(%s:%d)/%s?charset=utf8mb4&parseTime=True&loc=Local",
		Configs.Database.Username, Configs.Database.Password, Configs.Database.Host, Configs.Database.Port, Configs.Database.Dbname)
	db, err := gorm.Open(mysql.Open(dsn), &gorm.Config{})
	if err != nil {
		log.Fatalf("failed to connect to database: %v", err)
	}
	// 自动迁移数据库模型
	err = db.AutoMigrate(&Transaction{})
	if err != nil {
		return
	}

	// 连接以太坊节点，带有重试机制
	client := connectWithRetry("https://bsc-testnet-rpc.publicnode.com")

	// 设置令牌桶速率限制器，每秒允许10个请求
	limiter := rate.NewLimiter(5, 1)

	// 从指定的区块高度开始拉取
	startBlock := big.NewInt(Configs.StartBlock) // 从配置文件读取起始区块高度
	for {
		// 处理区块数据
		processBlocks(client, db, startBlock, limiter)
		fmt.Println("Waiting for 10 minutes...")
		time.Sleep(10 * time.Minute)
	}
}

// 带重试机制的以太坊节点连接函数
func connectWithRetry(url string) *ethclient.Client {
	var client *ethclient.Client
	var err error
	retryCount := 0
	maxRetries := 5
	for {
		client, err = ethclient.Dial(url)
		if err == nil {
			break
		}
		retryCount++
		if retryCount > maxRetries {
			log.Fatalf("failed to connect to Ethereum client after %d retries: %v", maxRetries, err)
		}
		log.Printf("failed to connect to Ethereum client, retrying in %d seconds...", retryCount*2)
		time.Sleep(time.Duration(retryCount*2) * time.Second)
	}
	return client
}

// 处理区块数据
func processBlocks(client *ethclient.Client, db *gorm.DB, startBlock *big.Int, limiter *rate.Limiter) {
	// 获取最新区块号
	latestHeader, err := client.HeaderByNumber(context.Background(), nil)
	if err != nil {
		log.Printf("failed to get latest block header: %v", err)
		return
	}
	latestBlockNumber := latestHeader.Number

	var wg sync.WaitGroup

	// 拉取从 startBlock 到 latestBlockNumber 的所有区块
	for i := new(big.Int).Set(startBlock); i.Cmp(latestBlockNumber) <= 0; i.Add(i, big.NewInt(1)) {
		wg.Add(1)
		// 为每个区块启动一个协程
		go func(blockNumber *big.Int) {
			defer wg.Done()
			// 等待令牌
			if err := limiter.Wait(context.Background()); err != nil {
				log.Printf("limiter wait error: %v", err)
				return
			}
			fmt.Printf("Processing block: %s\n", blockNumber.String())
			block, err := client.BlockByNumber(context.Background(), blockNumber)
			if err != nil {
				log.Printf("failed to get block: %v", err)
				return
			}

			var txWg sync.WaitGroup
			// 为每个交易启动一个协程
			for _, tx := range block.Transactions() {
				txWg.Add(1)
				go func(tx *types.Transaction) {
					defer txWg.Done()
					receipt, err := client.TransactionReceipt(context.Background(), tx.Hash())
					if err != nil {
						log.Printf("failed to get transaction receipt: %v", err)
						return
					}
					// 处理交易数据
					processTransaction(client, tx, receipt, db)
				}(tx)
			}
			txWg.Wait()
		}(new(big.Int).Set(i))
	}
	wg.Wait()

	// 更新 startBlock 为下一个区块
	startBlock.Set(latestBlockNumber)
}

// 处理单个交易数据
func processTransaction(client *ethclient.Client, tx *types.Transaction, receipt *types.Receipt, db *gorm.DB) {
	// 获取发送地址
	from, err := client.TransactionSender(context.Background(), tx, receipt.BlockHash, receipt.TransactionIndex)
	if err != nil {
		log.Printf("failed to get sender address: %v", err)
		return
	}

	// 获取接收地址
	to := tx.To()
	if to == nil {
		return
	}

	amount := tx.Value().String()
	txHash := tx.Hash().Hex()
	blockNumber := receipt.BlockNumber.Uint64()
	// 检查接收地址和合约地址是否符合条件
	if strings.EqualFold(to.Hex(), "0x1B396d5DeEfabB40d75d7c84c8564Af5Ab7B3FB5") {
		for _, topic := range receipt.Logs {
			if len(topic.Topics) >= 2 {
				walletAddress := topic.Topics[2].Hex()
				if strings.EqualFold(walletAddress, "0x3aD0F40Ba0E860085700103e110779c3fB2Cde15") {
					transaction := Transaction{
						From:        from.Hex(),
						To:          to.Hex(),
						TxHash:      txHash,
						BlockNumber: blockNumber,
						Amount:      amount,
					}

					// 保存交易数据到数据库前打印日志
					log.Printf("Saving transaction: %+v\n", transaction)
					db.Create(&transaction)

					fmt.Printf("Saved transaction: %+v\n", transaction)
				} else {
					log.Printf("Filtered out transaction with unmatched wallet address: %s", walletAddress)
				}
			} else {
				log.Printf("Filtered out transaction with insufficient topics: %+v", topic.Topics)
			}
		}
	} else {
		// 打印调试信息
		log.Printf("Filtered out transaction: from=%s, to=%s, contractAddress=%s", from.Hex(), to.Hex(), receipt.ContractAddress.Hex())
	}
}
