package main

import (
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"time"
)

// TransactionListDto 用于传递请求参数
type TransactionListDto struct {
	ChainShortName       string `json:"chainShortName"`
	Address              string `json:"address"`
	ProtocolType         string `json:"protocolType"`
	TokenContractAddress string `json:"tokenContractAddress"`
	StartBlockHeight     string `json:"startBlockHeight"`
	EndBlockHeight       string `json:"endBlockHeight"`
	IsFromOrTo           string `json:"isFromOrTo"`
	Page                 string `json:"page"`
	Limit                string `json:"limit"`
}

// Transaction 代表单个交易
type Transaction struct {
	TxId   string `json:"txId"`
	To     string `json:"to"`
	Amount string `json:"amount"`
}

// TransactionListResultVo 代表 API 的返回结果
type TransactionListResultVo struct {
	Data []struct {
		ChainFullName    string        `json:"chainFullName"`
		TransactionLists []Transaction `json:"transactionLists"`
	} `json:"data"`
}

// getTransactionList 发送请求到 OKLink 并获取交易列表
func getTransactionList(dto TransactionListDto, accessKey string) (*TransactionListResultVo, error) {
	client := &http.Client{
		Timeout: 20 * time.Second,
	}

	url := "https://www.oklink.com/api/v5/explorer/address/transaction-list"
	req, err := http.NewRequest("GET", url, nil)
	if err != nil {
		return nil, err
	}

	q := req.URL.Query()
	q.Add("chainShortName", dto.ChainShortName)
	q.Add("address", dto.Address)
	q.Add("protocolType", dto.ProtocolType)
	q.Add("tokenContractAddress", dto.TokenContractAddress)
	q.Add("startBlockHeight", dto.StartBlockHeight)
	q.Add("endBlockHeight", dto.EndBlockHeight)
	q.Add("isFromOrTo", dto.IsFromOrTo)
	q.Add("page", dto.Page)
	q.Add("limit", dto.Limit)
	req.URL.RawQuery = q.Encode()

	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Ok-Access-Key", accessKey)

	resp, err := client.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("unexpected status code: %d", resp.StatusCode)
	}

	var result TransactionListResultVo
	err = json.NewDecoder(resp.Body).Decode(&result)
	if err != nil {
		return nil, err
	}

	return &result, nil
}

func main() {
	dto := TransactionListDto{
		ChainShortName:       "bsc",
		Address:              "0x6f1E09af61c17c2Fc4EB65D0936099Bbf9086cDc",
		ProtocolType:         "token_20",
		TokenContractAddress: "0xF3E7A9eF1D84bf7CCEa65A298AA6358822f5Ee6B",
		StartBlockHeight:     "39343178",
		EndBlockHeight:       "39343459",
		IsFromOrTo:           "to",
		Page:                 "1",
		Limit:                "100",
	}

	accessKey := "5ccbf84a-88bf-4317-9e20-a206a7c0b8bf" // 替换为你的实际密钥

	result, err := getTransactionList(dto, accessKey)
	if err != nil {
		log.Fatalf("Failed to get transaction list: %v", err)
	}

	if len(result.Data) > 0 {
		fmt.Println(result.Data[0].ChainFullName)
		for _, transaction := range result.Data[0].TransactionLists {
			log.Printf("txId: %s, toAddress: %s, qty: %s", transaction.TxId, transaction.To, transaction.Amount)
		}
	}
}
