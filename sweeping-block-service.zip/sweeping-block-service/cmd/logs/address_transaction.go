package main

import (
	"context"
	"fmt"
	"golang.org/x/time/rate"
	"gopkg.in/yaml.v3"
	"log"
	"math/big"
	"os"
	"strings"
	"sync"
	"time"

	"github.com/ethereum/go-ethereum/core/types"
	"github.com/ethereum/go-ethereum/ethclient"
	"gorm.io/driver/mysql"
	"gorm.io/gorm"
)

var Configs Config

// Config represents the configuration structure
type Config struct {
	Database   DatabaseConfig `yaml:"databaseConfig"`
	StartBlock int64          `yaml:"startBlock"`
	NodeUrl    string         `yaml:"nodeUrl"`
	Filter     FilterConfig   `yaml:"filter"`
}

// FilterConfig details
type FilterConfig struct {
	ContractAddress string `yaml:"contractAddress"`
	WalletAddress   string `yaml:"walletAddress"`
	Enable          bool   `yaml:"enable"`
}

// DatabaseConfig holds the database connection details
type DatabaseConfig struct {
	Host     string `yaml:"host"`
	Port     int    `yaml:"port"`
	Username string `yaml:"username"`
	Password string `yaml:"password"` // second
	Dbname   string `yaml:"dbname"`   // second
}

// Transaction represents a blockchain transaction
type Transaction struct {
	From        string `gorm:"primaryKey"`
	To          string
	TxHash      string
	BlockNumber uint64
	Amount      string
}

// InitConfigDev 初始化yaml config
func initConfigDev() error {
	// 获取当前运行目录
	exePath, err := os.Executable()
	log.Printf(" currion path %v", exePath)
	file, err := os.ReadFile("../../config/config.yaml")
	if err != nil {
		log.Println("read config-dev.yaml fail", err)
		return err
	}

	err = yaml.Unmarshal(file, &Configs)
	if err != nil {
		log.Println("yaml unmarshal fail")
		return err
	}
	return nil
}

func main() {
	// 加载配置
	if err := initConfigDev(); err != nil {
		log.Fatalf("Error unmarshalling config: %v", err)
	}

	// MySQL 数据库连接信息
	dsn := fmt.Sprintf("%s:%s@tcp(%s:%d)/%s?charset=utf8mb4&parseTime=True&loc=Local",
		Configs.Database.Username, Configs.Database.Password, Configs.Database.Host, Configs.Database.Port, Configs.Database.Dbname)
	db, err := gorm.Open(mysql.Open(dsn), &gorm.Config{})
	if err != nil {
		log.Fatalf("failed to connect to database: %v", err)
	}
	// 自动迁移数据库模型
	err = db.AutoMigrate(&Transaction{})
	if err != nil {
		return
	}

	// 连接以太坊节点，带有重试机制
	client := connectWithRetry(Configs.NodeUrl)

	// 设置令牌桶速率限制器，每秒允许3个请求
	limiter := rate.NewLimiter(5, 1)

	// 从指定的区块高度开始拉取
	startBlock := big.NewInt(Configs.StartBlock) // 从配置文件读取起始区块高度
	for {
		// 处理区块数据
		processBlocks(client, db, startBlock, limiter)
		fmt.Println("Waiting for 10 minutes...")
		time.Sleep(10 * time.Minute)
	}
}

// 带重试机制的以太坊节点连接函数
func connectWithRetry(url string) *ethclient.Client {
	var client *ethclient.Client
	var err error
	retryCount := 0
	maxRetries := 5
	for {
		client, err = ethclient.Dial(url)
		if err == nil {
			break
		}
		retryCount++
		if retryCount > maxRetries {
			log.Fatalf("failed to connect to Ethereum client after %d retries: %v", maxRetries, err)
		}
		log.Printf("failed to connect to Ethereum client, retrying in %d seconds...", retryCount*2)
		time.Sleep(time.Duration(retryCount*2) * time.Second)
	}
	return client
}

// 处理区块数据
func processBlocks(client *ethclient.Client, db *gorm.DB, startBlock *big.Int, limiter *rate.Limiter) {
	// 获取最新区块号
	latestHeader, err := client.HeaderByNumber(context.Background(), nil)
	if err != nil {
		log.Printf("failed to get latest block header: %v", err)
		return
	}
	latestBlockNumber := latestHeader.Number

	var wg sync.WaitGroup

	// 拉取从 startBlock 到 latestBlockNumber 的所有区块
	for i := new(big.Int).Set(startBlock); i.Cmp(latestBlockNumber) <= 0; i.Add(i, big.NewInt(5)) {
		wg.Add(1)
		// 为每个区块启动一个协程
		go func(blockNumber *big.Int) {
			defer wg.Done()
			// 等待令牌
			if err := limiter.Wait(context.Background()); err != nil {
				log.Printf("limiter wait error: %v", err)
				return
			}
			fmt.Printf("Processing block: %s\n", blockNumber.String())
			block, err := client.BlockByNumber(context.Background(), blockNumber)
			if err != nil {
				log.Printf("failed to get block: %v", err)
				return
			}

			var txWg sync.WaitGroup
			// 为每个交易启动一个协程
			for _, tx := range block.Transactions() {
				txWg.Add(1)
				go func(tx *types.Transaction) {
					defer txWg.Done()
					receipt, err := client.TransactionReceipt(context.Background(), tx.Hash())
					if err != nil {
						log.Printf("failed to get transaction receipt: %v", err)
						return
					}
					// 处理交易数据
					processTransaction(client, tx, receipt, db)
				}(tx)
			}
			txWg.Wait()
		}(new(big.Int).Set(i))
	}
	wg.Wait()

	// 更新 startBlock 为下一个区块
	startBlock.Set(latestBlockNumber)
}

// 处理单个交易数据
func processTransaction(client *ethclient.Client, tx *types.Transaction, receipt *types.Receipt, db *gorm.DB) {
	// 获取发送地址
	from, err := client.TransactionSender(context.Background(), tx, receipt.BlockHash, receipt.TransactionIndex)
	if err != nil {
		log.Printf("failed to get sender address: %v", err)
		return
	}

	// 获取接收地址
	to := tx.To()
	if to == nil {
		return
	}

	txHash := tx.Hash().Hex()
	blockNumber := receipt.BlockNumber.Uint64()
	// 检查接收地址和合约地址是否符合条件
	if strings.EqualFold(to.Hex(), Configs.Filter.ContractAddress) {
		for _, topic := range receipt.Logs {
			if len(topic.Topics) == 3 {
				walletAddress := hexToAddress(topic.Topics[2].Hex())
				bigint := new(big.Int).SetBytes(topic.Data)
				amount := hexToBigInt(bigint.String())
				log.Printf("Amount: %+v", amount)
				transaction := Transaction{
					From:        from.Hex(),
					To:          walletAddress,
					TxHash:      txHash,
					BlockNumber: blockNumber,
					Amount:      amount,
				}
				// 保存交易数据到数据库前打印日志
				log.Printf("Saving transaction: %+v\n %+v", transaction, blockNumber)
				if Configs.Filter.Enable && strings.EqualFold(walletAddress, Configs.Filter.WalletAddress) {
					db.Create(&transaction)
				} else {
					db.Create(&transaction)
				}
				fmt.Printf("Saved transaction: %+v\n", transaction)
			} else {
				log.Printf("Filtered out transaction with insufficient topics: %+v", topic.Topics)
			}
		}
	} else {
		// 打印调试信息
		//log.Printf("Filtered out transaction: from=%s, to=%s, contractAddress=%s", from.Hex(), to.Hex(), receipt.ContractAddress.Hex())
	}
}

func hexToAddress(hexStr string) string {
	// 去掉前缀 "0x" 或 "0X"（如果有）
	if strings.HasPrefix(hexStr, "0x") || strings.HasPrefix(hexStr, "0X") {
		hexStr = hexStr[2:]
	}

	// 去掉前导零并获取最后 40 个字符（20 字节）
	hexStr = strings.TrimLeft(hexStr, "0")
	if len(hexStr) > 40 {
		hexStr = hexStr[len(hexStr)-40:]
	}

	// 将字符串格式化为标准的 Ethereum 地址格式
	address := "0x" + hexStr
	return address
}

// hexToBigInt 将十六进制字符串转换为 *big.Int
func hexToBigInt(hexStr string) string {
	// 去掉前缀 "0x" 或 "0X"（如果有）
	if strings.HasPrefix(hexStr, "0x") || strings.HasPrefix(hexStr, "0X") {
		hexStr = hexStr[2:]
	}

	// 将十六进制字符串转换为 *big.Int
	amount := new(big.Int)
	amount.SetString(hexStr, 10)
	// 将 *big.Int 转换为 *big.Float
	valueFloat := new(big.Float).SetInt(amount)

	// 创建一个表示 10^18 的 *big.Float
	divisor := new(big.Float).SetFloat64(1e18)

	// 执行除法运算
	result := new(big.Float).Quo(valueFloat, divisor)
	// 将结果转换为字符串
	resultStr := result.Text('f', 18)
	return resultStr
}

// weiToEther 将 Wei 转换为 Ether
func weiToEther(wei *big.Int) *big.Float {
	ether := new(big.Float).SetInt(wei)
	// 1 Ether = 10^18 Wei
	ether.Quo(ether, big.NewFloat(1e18))
	return ether
}
